/**
 * Initialize and start the express application.
 */
if (!process.env.NODE_ENV) {
  process.env.NODE_ENV = 'development'
}

const fs = require('fs')
const express = require('express')
const multer = require('multer')
const cors = require('cors')
const config = require('config')
const morgan = require('morgan')
const clamav = require('clamav.js')
const logger = require('./logger')

// Initialize ClamAV
const clamavScanner = clamav.createScanner(config.CLAMAV_PORT, config.CLAMAV_HOST)

// Create app
const app = express()
app.use(cors())

// Request logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'))
} else if (process.env.NODE_ENV === 'production') {
  app.use(morgan('common', { skip: (req, res) => res.statusCode < 400 }))
}

// Configure the routes
const upload = multer({ dest: 'uploads/' }).single('file')
app.post(
  `${config.CONTEXT_PATH}/scan`,

  /**
   * Upload handler.
   */
  (req, res, next) => {
    upload(req, res, (err) => {
      if (err) {
        err.status = 400
        next(err)

        // Delete the file if any
        if (req.file && req.file.path) {
          fs.unlink(req.file.path)
        }
      } else {
        next()
      }
    })
  },

  /**
   * Scan handler.
   */
  (req, res, next) => {
    console.log(req.file)
    if (!req.file) {
      return next({ status: 400, message: 'file is required' })
    }

    // Scan
    clamavScanner.scan(req.file.path, (err, object, malicious) => {
      // Delete the file
      fs.unlink(req.file.path)

      if (err) {
        console.log(object.path + ': ' + err);
      }
      else if (malicious) {
        console.log(object.path + ': ' + malicious + ' FOUND');
      }
      else {
        console.log(object)
        console.log(object.path + ': OK');
      }
      res.json({ infected: false })
    })
  })

// Error handler
app.use((err, req, res, next) => {
  let status = err.status || 500
  let message = err.message || 'Internal server error'
  res.status(status).send({ message })
  logger.error(err)
})

app.listen(config.PORT, '0.0.0.0')
logger.info(`Express server listening on port ${config.PORT} in ${process.env.NODE_ENV} mode`)
